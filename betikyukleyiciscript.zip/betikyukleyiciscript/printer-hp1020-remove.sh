#!/bin/bash
rm -rf /var/lib/betikyukleyici/hp1020
exit 0
