#!/bin/bash
apt remove opera* -y
rm -rf /var/lib/betikyukleyici/opera
exit 0
