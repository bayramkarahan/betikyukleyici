#!/bin/bash
apt remove zoom -y
rm -rf /var/lib/betikyukleyici/zoom
exit 0
