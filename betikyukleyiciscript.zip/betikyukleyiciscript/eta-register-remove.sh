#!/bin/bash
apt remove eta-register -y
rm -rf /var/lib/betikyukleyici/eta-register
exit 0
