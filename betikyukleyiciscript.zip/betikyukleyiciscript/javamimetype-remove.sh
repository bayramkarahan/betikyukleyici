#!/bin/bash
apt remove javamimetype -y
rm -rf /var/lib/betikyukleyici/javamimetype
exit 0
