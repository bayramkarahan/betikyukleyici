#!/bin/bash
apt remove pardus-remaster -y
rm -rf /var/lib/betikyukleyici/remasterImaj
exit 0
