#!/bin/bash
apt remove ttkbfont -y
rm -rf /var/lib/betikyukleyici/ttkbfont
exit 0
