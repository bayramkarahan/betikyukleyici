#!/bin/bash

mkdir /var/lib/betikyukleyici
rm -rf /var/lib/betikyukleyici/giriscozunurluk
exit 0
