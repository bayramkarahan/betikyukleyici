#!/bin/bash

rm -rf /var/lib/betikyukleyici/userupdate
exit 0
