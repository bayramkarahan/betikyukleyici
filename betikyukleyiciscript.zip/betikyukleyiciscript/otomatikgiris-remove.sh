#!/bin/bash

rm -rf /var/lib/betikyukleyici/otomatikgiris
exit 0
