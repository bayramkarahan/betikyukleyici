#!/bin/bash

rm -rf /var/lib/betikyukleyici/paroladegistir
exit 0
