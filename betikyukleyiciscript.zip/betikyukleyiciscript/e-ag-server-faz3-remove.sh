#!/bin/bash
apt remove e-ag -y
rm -rf /var/lib/betikyukleyici/e-ag
exit 0
