#!/bin/bash
apt pardus-lightdm-greeter-qrkilit -y
rm -rf /var/lib/betikyukleyici/qrkilit
exit 0
