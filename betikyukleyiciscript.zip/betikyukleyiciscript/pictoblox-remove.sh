#!/bin/bash
apt remove pictoblox -y
rm -rf /var/lib/betikyukleyici/pictoblox
exit 0
