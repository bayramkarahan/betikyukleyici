#!/bin/bash
apt remove betikyukleyici -y
rm -rf /var/lib/betikyukleyici/betik
exit 0
