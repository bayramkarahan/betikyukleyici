#!/bin/bash
apt remove e-tahta -y
rm -rf /var/lib/betikyukleyici/e-tahta
exit 0
