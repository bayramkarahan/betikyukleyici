#!/bin/bash
apt remove gperiodic -y
rm -rf /var/lib/betikyukleyici/PeriyodikCetvel
exit 0
