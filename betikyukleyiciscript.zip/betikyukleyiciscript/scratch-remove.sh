#!/bin/bash
apt remove scratch -y
rm -rf /var/lib/betikyukleyici/scratch
exit 0
