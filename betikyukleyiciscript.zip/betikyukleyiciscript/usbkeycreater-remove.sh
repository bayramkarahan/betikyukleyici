#!/bin/bash
apt remove usbkeycreaterusers -y
rm -rf /var/lib/betikyukleyici/usbkeycreaterusers
exit 0
