#!/bin/bash
apt remove epson* -y
rm -rf /var/lib/betikyukleyici/epson
exit 0
