#!/bin/bash
apt remove e-etap-greeter -y
rm -rf /var/lib/betikyukleyici/etap-greeter
exit 0
