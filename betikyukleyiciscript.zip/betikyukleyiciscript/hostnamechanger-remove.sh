#!/bin/bash
apt remove hostnamechanger -y
rm -rf /var/lib/betikyukleyici/hostnamechanger
exit 0
