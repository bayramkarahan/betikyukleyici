#!/bin/bash
rm -rf /var/lib/betikyukleyici/foxitreader
exit 0
