#!/bin/bash

rm -rf /var/lib/betikyukleyici/mozaik3d
exit 0
