#!/bin/bash
rm -rf /var/lib/betikyukleyici/hp1018
exit 0
