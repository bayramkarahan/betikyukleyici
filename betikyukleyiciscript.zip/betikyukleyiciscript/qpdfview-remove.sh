#!/bin/bash
apt remove qpdfview -y
rm -rf /var/lib/betikyukleyici/qpdfview
exit 0
