#!/bin/bash


apt remove smartboard -y

rm -rf /var/lib/betikyukleyici/smartboard
exit 0
