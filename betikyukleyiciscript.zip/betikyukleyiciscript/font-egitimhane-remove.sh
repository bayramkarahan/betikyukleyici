#!/bin/bash
apt remove egitimhane -y
rm -rf /var/lib/betikyukleyici/egitimhanefont
exit 0
