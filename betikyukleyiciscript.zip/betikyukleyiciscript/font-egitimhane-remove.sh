#!/bin/bash
apt remove diktemelabc -y
rm -rf /var/lib/betikyukleyici/diktemelabc
exit 0
