#!/bin/bash
apt remove winemimetype -y
rm -rf /var/lib/betikyukleyici/winemimetype
exit 0
