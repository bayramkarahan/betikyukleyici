#!/bin/bash
apt remove idle3 -y
rm -rf /var/lib/betikyukleyici/idle3
exit 0
