#!/bin/bash
apt remove akisdiyagram -y
rm -rf /var/lib/betikyukleyici/akisdiyagram
exit 0
