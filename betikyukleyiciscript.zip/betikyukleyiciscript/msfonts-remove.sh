#!/bin/bash
apt remove ttf-mscore-installer -y
rm -rf /var/lib/betikyukleyici/msfonts
exit 0
