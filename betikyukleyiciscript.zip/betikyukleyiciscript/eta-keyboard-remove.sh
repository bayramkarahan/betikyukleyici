#!/bin/bash
apt remove eta-keyboard -y
rm -rf /var/lib/betikyukleyici/eta-keyboard
exit 0
