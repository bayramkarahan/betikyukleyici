#!/bin/bash
apt remove antropi -y
rm -rf /var/lib/betikyukleyici/antropi
exit 0
