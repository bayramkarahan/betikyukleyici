#!/bin/bash
apt remove libre* -y
rm -rf /var/lib/betikyukleyici/LibreOfis
exit 0
