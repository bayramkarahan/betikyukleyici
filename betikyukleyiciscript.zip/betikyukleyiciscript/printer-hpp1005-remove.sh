#!/bin/bash
rm -rf /var/lib/betikyukleyici/hpp1005
exit 0
