#!/bin/bash
apt remove pardus-yuzyil -y

rm -rf /var/lib/betikyukleyici/yuzuncuyil
exit 0
