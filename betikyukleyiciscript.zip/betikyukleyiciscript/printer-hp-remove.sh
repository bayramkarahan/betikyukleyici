#!/bin/bash
rm -rf /var/lib/betikyukleyici/hp
exit 0
