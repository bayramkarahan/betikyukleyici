#!/bin/bash
apt remove e-uctas -y
rm -rf /var/lib/betikyukleyici/e-uctas
exit 0
