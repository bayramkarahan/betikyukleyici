#!/bin/bash
apt remove e-ag-client -y
rm -rf /var/lib/betikyukleyici/e-ag-client
exit 0
