#!/bin/bash
rm -rf /var/lib/betikyukleyici/ilkbakim
exit 0
