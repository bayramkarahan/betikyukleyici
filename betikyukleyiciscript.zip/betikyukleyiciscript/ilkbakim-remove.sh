#!/bin/bash
rm -rf /var/lib/betikyukleyici/ilkhazirlikwine

apt autoremove -y
exit 0
