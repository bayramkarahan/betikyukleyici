#!/bin/bash
apt remove flowingtr -y
rm -rf /var/lib/betikyukleyici/flowingtr
exit 0
