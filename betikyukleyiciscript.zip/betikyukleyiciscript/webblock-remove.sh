#!/bin/bash
apt remove webblock -y
rm -rf /var/lib/betikyukleyici/webblock
exit 0
