#!/bin/bash
apt remove setwallpaper -y

rm -rf /var/lib/betikyukleyici/setwallpaper
exit 0
