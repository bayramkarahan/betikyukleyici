#!/bin/bash

rm -rf /var/lib/betikyukleyici/userreset
exit 0
