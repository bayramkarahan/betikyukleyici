#!/bin/bash
rm -rf /var/lib/betikyukleyici/bluetooth
exit 0
