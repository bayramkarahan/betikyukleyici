#!/bin/bash

rm -rf /var/lib/betikyukleyici/firefox
exit 0
