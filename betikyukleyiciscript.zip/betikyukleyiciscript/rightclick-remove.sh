#!/bin/bash
gsettings set org.gnome.desktop.a11y.mouse secondary-click-enabled false

rm -rf /var/lib/betikyukleyici/rightclick
exit 0
