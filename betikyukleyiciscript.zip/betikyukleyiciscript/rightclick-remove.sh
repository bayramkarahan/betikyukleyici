#!/bin/bash
apt remove rightclicklongpress -y

rm -rf /var/lib/betikyukleyici/rightclick
exit 0
