#!/bin/bash
apt remove e-sabit -y
rm -rf /var/lib/betikyukleyici/e-sabit
exit 0
