#!/bin/bash
apt remove e-carp -y
rm -rf /var/lib/betikyukleyici/e-carp
exit 0
