#!/bin/bash
apt remove wps* -y
rm -rf /var/lib/betikyukleyici/wpsOfis
exit 0
