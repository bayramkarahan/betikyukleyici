#!/bin/bash
apt remove e-zil -y
rm -rf /var/lib/betikyukleyici/e-zil
exit 0
