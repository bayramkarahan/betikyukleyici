#!/bin/bash
apt remove flashplayer -y

rm -rf /var/lib/betikyukleyici/flashplayer
exit 0
