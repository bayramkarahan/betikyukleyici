#!/bin/bash
apt remove e-kilit -y
rm -rf /var/lib/betikyukleyici/e-kilit
exit 0
