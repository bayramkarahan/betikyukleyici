#!/bin/bash
apt remove okuyorum -y
rm -rf /var/lib/betikyukleyici/okuyorum
exit 0
