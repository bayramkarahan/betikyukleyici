#!/bin/bash

rm -rf /var/lib/betikyukleyici/update
exit 0
