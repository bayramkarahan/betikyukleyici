#!/bin/bash
apt remove zamanligorev -y
rm -rf /var/lib/betikyukleyici/zamanligorev
exit 0
