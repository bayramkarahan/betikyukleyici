#!/bin/bash
rm -rf /var/lib/betikyukleyici/hp1005
exit 0
