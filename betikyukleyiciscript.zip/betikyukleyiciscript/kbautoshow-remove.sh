#!/bin/bash
apt remove etahta-virtualkeyboard-integration -y
rm -rf /var/lib/betikyukleyici/etahta-virtualkeyboard-integration
exit 0
