#!/bin/bash
apt remove keyboardautoshow -y
rm -rf /var/lib/betikyukleyici/keyboardautoshow
exit 0
