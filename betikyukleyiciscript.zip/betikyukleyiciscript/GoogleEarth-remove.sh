#!/bin/bash
apt remove google-earth-pro-stable -y
rm -rf /var/lib/betikyukleyici/Googleearth
exit 0
