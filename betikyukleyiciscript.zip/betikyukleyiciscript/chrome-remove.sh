#!/bin/bash
apt remove google-chrome-stable -y
rm -rf /var/lib/betikyukleyici/Google-Chrome
exit 0
